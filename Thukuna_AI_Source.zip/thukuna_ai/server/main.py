import os
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title='Thukuna AI')
client = OpenAI(api_key=os.environ.get('OPENAI_API_KEY'))
MODEL = os.environ.get('OPENAI_MODEL', 'gpt-5.5')
class ChatRequest(BaseModel):
    messages: list[dict]
@app.post('/api/chat')
def chat(req: ChatRequest):
    if not os.environ.get('OPENAI_API_KEY'):
        return {'reply': 'The server owner needs to configure OPENAI_API_KEY first.'}
    safe = [{'role': m['role'], 'content': str(m.get('content',''))[:6000]} for m in req.messages if m.get('role') in ('user','assistant')]
    response = client.responses.create(model=MODEL, instructions='You are Thukuna AI, a helpful, witty AI companion. Be respectful and safe.', input=safe)
    return {'reply': response.output_text}
@app.get('/')
def home(): return FileResponse('web/index.html')
app.mount('/', StaticFiles(directory='web'), name='web')
