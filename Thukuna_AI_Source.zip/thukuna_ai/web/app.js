const chat=document.querySelector('#chat'),form=document.querySelector('#form'),input=document.querySelector('#prompt');
let history=JSON.parse(localStorage.getItem('thukuna_history')||'[]'),voice=false;
function render(){chat.innerHTML='';for(const m of history){const d=document.createElement('div');d.className='msg '+(m.role==='user'?'user':'bot');d.textContent=m.content;chat.append(d)}chat.scrollTop=chat.scrollHeight}
function save(){localStorage.setItem('thukuna_history',JSON.stringify(history.slice(-100)));render()}
async function send(text){if(!text.trim())return;history.push({role:'user',content:text});save();input.value='';const wait={role:'assistant',content:'Thinking…'};history.push(wait);render();try{const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history.filter(x=>x!==wait).slice(-20)})});if(!r.ok)throw Error('Backend not connected');const data=await r.json();wait.content=data.reply||'No reply received.';}catch(e){wait.content='Thukuna AI is not connected to its AI server yet. Set up the backend using the README instructions.';}save();if(voice&&'speechSynthesis'in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(wait.content));}}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value)});
document.querySelector('#clear').onclick=()=>{history=[];save()};
document.querySelector('#speak').onclick=e=>{voice=!voice;e.currentTarget.textContent='🔊 Voice replies: '+(voice?'on':'off')};
document.querySelector('#mic').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){alert('Voice input is not supported in this browser. Try Chrome.');return}const rec=new SR();rec.lang=navigator.language||'en-US';rec.onresult=e=>send(e.results[0][0].transcript);rec.start()};
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});render();
