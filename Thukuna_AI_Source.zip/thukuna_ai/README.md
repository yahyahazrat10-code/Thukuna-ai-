# Thukuna AI — phone-friendly starter

This is a **source-code starter**, not an installable APK and not yet a hosted app.
It includes a mobile web chat, local conversation history, browser voice input/output, and a Python API server.

## Run the server

1. Use a computer or a Python hosting service that can run a persistent FastAPI server.
2. Install dependencies: `pip install -r server/requirements.txt`
3. Set `OPENAI_API_KEY` as a server environment variable. Never put the API key in the web folder or in a public repository.
4. Optionally set `OPENAI_MODEL` to a model available to your API account.
5. From the project root (the folder containing `web` and `server`), run: `uvicorn server.main:app --host 0.0.0.0 --port 8000`.
6. Open the hosted HTTPS address in Chrome on Android. Use Chrome's menu → Add to Home screen / Install app.

## Phone-only note

You can download and inspect these files on a Samsung phone, but hosting the Python backend and securely configuring an API key is not a one-tap phone-only setup. Ask a parent/guardian before enabling any paid API billing.

## Floating avatar limitation

This web app cannot float over other Android apps. A separate native Android overlay service and an APK build are needed for that feature. This starter does not request overlay permission.

## Privacy

Chat history is stored in this browser's local storage. The server receives recent chat messages to generate replies. Do not send passwords or sensitive personal information.
